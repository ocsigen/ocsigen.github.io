let warning s = Dom_html.window##alert (s)
