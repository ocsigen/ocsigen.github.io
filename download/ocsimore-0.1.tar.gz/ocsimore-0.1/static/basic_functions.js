<!--
function openclose(id1,id2) 
   {
   if (document.getElementById && 
	document.getElementById(id1) && 
	document.getElementById(id2) != null) 
     {
     document.getElementById(id1).style.visibility='visible';
     document.getElementById(id1).style.display='block';
     document.getElementById(id2).style.visibility='hidden';
     document.getElementById(id2).style.display='none';
     }
   }
//-->