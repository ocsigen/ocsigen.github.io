# 27 "xmllexer.mll"
 

        (** A lexical analyzer. *)


open Camlp4

module Loc = Camlp4.PreCast.Loc

open Lexing

(* Basic types *)
module BasicTypes = struct
type attr =  [`Attr of string | `CamlAttr of string] 
type valeur =   [`Val of string | `CamlVal of string] 
type attribute =  [`Attribute of (attr * valeur) | `CamlList of string] 
type token =
   Tag of (string * (attribute list) * bool)
  | PCData of string
  | Endtag of string
  | Comment of string
  | CamlString of string
  | CamlList of string
  | CamlExpr of string
  | Whitespace of string
  | Eof 

end;;

open BasicTypes

(* Error report *)
module Error = struct

        type t =
                | EUnterminatedComment
                | EUnterminatedString
                | EIdentExpected
                | ECloseExpected
                | ENodeExpected
                | EAttributeNameExpected
                | EAttributeValueExpected
                | EUnterminatedEntity
                | ECamlIdentExpected
                | WIntricatedComments

        exception E of t

        open Format

        let print ppf = function
        | EUnterminatedComment ->
                        fprintf ppf "Unterminated Comment"
        | EUnterminatedString  ->
                        fprintf ppf "Unterminated String"
        | EIdentExpected ->
                        fprintf ppf "Ident Expected"
        | ECloseExpected ->
                        fprintf ppf "Close Expected"
        | ENodeExpected ->
                        fprintf ppf "Node Expected"
        | EAttributeNameExpected ->
                        fprintf ppf "Attribute Name Expected"
        | EAttributeValueExpected ->
                        fprintf ppf "Attribute Value Expected"
        | EUnterminatedEntity ->
                        fprintf ppf "Unterminated Entity"
        | ECamlIdentExpected ->
                        fprintf ppf "Caml Ident Expected"
        | WIntricatedComments ->
                        fprintf ppf "Intricated comments (non valid XML)"


    let to_string x =
            let b = Buffer.create 50 in
            let () = bprintf b "%a" print x in Buffer.contents b
end;;

let module M = ErrorHandler.Register(Error) in ()

open Error

(* To store some context information:
        *   loc       : position of the beginning of a string, quotation and comment
		*   entity : shall we translate entities or not
        *)

type context =
        { loc        : Loc.t    ;
        lexbuf     : lexbuf   ;
        buffer     : Buffer.t ;
        entity     : bool ;
		}

let default_context lb =
        { loc        = Loc.ghost ;
        lexbuf     = lb        ;
        buffer     = Buffer.create 256 ;
        entity	= true ;
		}

        (* To buffer string literals *)

let store c = Buffer.add_string c.buffer (Lexing.lexeme c.lexbuf)
let istore_char c i = Buffer.add_char c.buffer (Lexing.lexeme_char c.lexbuf i)
let buff_contents c =
        let contents = Buffer.contents c.buffer in
        Buffer.reset c.buffer; contents

let loc c = Loc.merge c.loc (Loc.of_lexbuf c.lexbuf)

let with_curr_loc f c = f { (c) with loc = Loc.of_lexbuf c.lexbuf } c.lexbuf
let parse f c = f c c.lexbuf

let lexeme c = Lexing.lexeme c.lexbuf
let store_string c s = Buffer.add_string c.buffer s

let extract_caml s prefix = 
        let i = String.index s '$'  in
        let j = String.index_from s (i+1) '$' in 
        let k = (if prefix then  String.index_from s (i+1) ':' else i) 
        in if k<j then String.sub s (k+1) (j-k-1) else failwith "Error : extract_caml"

        (* Deal with entities  *)
let idents = Hashtbl.create 0

let _ = begin
        Hashtbl.add idents "gt;" ">";
        Hashtbl.add idents "lt;" "<";
        Hashtbl.add idents "amp;" "&";
        Hashtbl.add idents "apos;" "'";
        Hashtbl.add idents "quot;" "\"";
end

        (* Update the current location with file name and line number. *)

let update_loc c line absolute chars =
        let lexbuf = c.lexbuf in
        let pos = lexbuf.lex_curr_p in
        lexbuf.lex_curr_p <- { pos with
        pos_lnum = if absolute then line else pos.pos_lnum + line;
        pos_bol = pos.pos_cnum - chars;
        }

let err error loc =
        Format.eprintf "Error: %a: %a@." Loc.print loc Error.print error ;
        raise(Loc.Exc_located(loc, Error.E error))

let warn error loc =
        Format.eprintf "Warning: %a: %a@." Loc.print loc Error.print error
        

# 155 "xmllexer.ml"
let __ocaml_lex_tables = {
  Lexing.lex_base = 
   "\000\000\241\255\245\255\001\000\004\000\000\000\009\000\011\000\
    \013\000\255\255\012\000\018\000\252\255\001\000\002\000\253\255\
    \249\255\000\000\000\000\247\255\000\000\000\000\244\255\000\000\
    \001\000\001\000\243\255\020\000\044\000\018\000\038\000\021\000\
    \251\255\010\000\001\000\019\000\022\000\254\255\006\000\006\000\
    \008\000\070\000\035\000\042\000\075\000\073\000\012\001\076\001\
    \154\001\232\001\016\000\032\000\020\000\063\002\001\000\141\002\
    \002\000\003\000\004\000\026\000\187\000\089\000\188\000\090\000\
    \189\000\200\000\201\000\216\000\215\000\217\000\218\000\245\000\
    \167\000\076\000\168\000\125\000";
  Lexing.lex_backtrk = 
   "\255\255\255\255\255\255\009\000\013\000\007\000\005\000\001\000\
    \001\000\255\255\004\000\005\000\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\002\000\001\000\255\255\001\000\255\255\
    \255\255\004\000\004\000\255\255\255\255\255\255\255\255\255\255\
    \003\000\004\000\255\255\002\000\000\000\255\255\001\000\255\255\
    \255\255\000\000\255\255\002\000\255\255\255\255\002\000\000\000\
    \255\255\255\255\255\255\255\255\255\255\004\000\004\000\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\003\000\255\255\003\000";
  Lexing.lex_default = 
   "\003\000\000\000\000\000\003\000\255\255\255\255\255\255\255\255\
    \003\000\000\000\255\255\255\255\000\000\255\255\255\255\000\000\
    \000\000\255\255\255\255\000\000\255\255\255\255\000\000\255\255\
    \255\255\255\255\000\000\255\255\255\255\030\000\030\000\032\000\
    \000\000\255\255\255\255\255\255\255\255\000\000\255\255\012\000\
    \255\255\044\000\255\255\255\255\044\000\037\000\255\255\255\255\
    \037\000\255\255\037\000\255\255\255\255\012\000\255\255\255\255\
    \255\255\255\255\255\255\255\255\032\000\255\255\255\255\255\255\
    \255\255\066\000\066\000\066\000\066\000\066\000\071\000\071\000\
    \012\000\255\255\012\000\255\255";
  Lexing.lex_trans = 
   "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\008\000\009\000\255\255\000\000\007\000\255\255\000\000\
    \009\000\000\000\011\000\000\000\007\000\010\000\008\000\255\255\
    \007\000\000\000\007\000\011\000\009\000\028\000\009\000\009\000\
    \008\000\028\000\035\000\016\000\004\000\255\255\005\000\255\255\
    \019\000\011\000\013\000\007\000\010\000\008\000\014\000\015\000\
    \255\255\255\255\011\000\255\255\028\000\028\000\015\000\038\000\
    \010\000\028\000\022\000\026\000\006\000\255\255\001\000\255\255\
    \036\000\010\000\033\000\037\000\015\000\040\000\037\000\012\000\
    \012\000\255\255\255\255\255\255\028\000\037\000\009\000\052\000\
    \255\255\034\000\037\000\255\255\037\000\255\255\000\000\000\000\
    \255\255\000\000\000\000\000\000\000\000\000\000\009\000\000\000\
    \000\000\000\000\063\000\063\000\000\000\000\000\000\000\000\000\
    \000\000\023\000\042\000\057\000\043\000\056\000\037\000\255\255\
    \017\000\255\255\021\000\024\000\020\000\025\000\058\000\018\000\
    \059\000\063\000\063\000\015\000\015\000\065\000\065\000\000\000\
    \012\000\012\000\255\255\000\000\255\255\000\000\000\000\255\255\
    \000\000\255\255\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\037\000\000\000\000\000\000\000\
    \037\000\000\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\062\000\064\000\064\000\000\000\
    \000\000\009\000\000\000\000\000\000\000\000\000\000\000\009\000\
    \000\000\000\000\255\255\255\255\000\000\000\000\000\000\000\000\
    \000\000\037\000\000\000\062\000\064\000\064\000\000\000\000\000\
    \000\000\255\255\255\255\255\255\255\255\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\255\255\037\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \061\000\063\000\063\000\037\000\037\000\037\000\037\000\255\255\
    \002\000\255\255\000\000\073\000\075\000\000\000\015\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\255\255\000\000\000\000\
    \000\000\000\000\255\255\070\000\000\000\012\000\000\000\000\000\
    \000\000\009\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\255\255\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\067\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\255\255\009\000\
    \000\000\069\000\000\000\255\255\068\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\009\000\
    \000\000\000\000\000\000\000\000\000\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\015\000\
    \015\000\000\000\000\000\000\000\000\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\049\000\
    \255\255\255\255\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\000\000\000\000\255\255\
    \255\255\255\255\255\255\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\255\255\000\000\000\000\
    \000\000\049\000\000\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\000\000\000\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\000\000\000\000\000\000\000\000\049\000\
    \000\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\054\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\055\000\000\000\000\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\000\000\000\000\000\000\000\000\055\000\000\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\000\000\000\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \000\000\000\000\000\000\000\000\055\000\000\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
    \000\000\000\000\000\000\000\000\000\000\000\000";
  Lexing.lex_check = 
   "\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\000\000\000\000\003\000\255\255\000\000\003\000\255\255\
    \039\000\255\255\006\000\255\255\007\000\010\000\008\000\008\000\
    \007\000\255\255\008\000\011\000\029\000\027\000\027\000\031\000\
    \000\000\027\000\034\000\005\000\000\000\003\000\000\000\003\000\
    \004\000\006\000\006\000\007\000\010\000\008\000\013\000\014\000\
    \030\000\008\000\011\000\008\000\027\000\028\000\029\000\033\000\
    \006\000\028\000\021\000\025\000\000\000\003\000\000\000\003\000\
    \035\000\011\000\031\000\036\000\038\000\039\000\040\000\042\000\
    \006\000\008\000\030\000\008\000\028\000\043\000\050\000\051\000\
    \041\000\031\000\052\000\041\000\059\000\044\000\255\255\255\255\
    \044\000\255\255\255\255\255\255\255\255\255\255\051\000\255\255\
    \255\255\255\255\061\000\063\000\255\255\255\255\255\255\255\255\
    \255\255\017\000\041\000\056\000\041\000\054\000\073\000\044\000\
    \004\000\044\000\020\000\023\000\018\000\024\000\057\000\004\000\
    \058\000\061\000\063\000\061\000\063\000\061\000\063\000\255\255\
    \061\000\063\000\041\000\255\255\041\000\255\255\255\255\044\000\
    \255\255\044\000\045\000\045\000\045\000\045\000\045\000\045\000\
    \045\000\045\000\045\000\045\000\045\000\045\000\045\000\045\000\
    \045\000\045\000\045\000\045\000\045\000\045\000\045\000\045\000\
    \045\000\045\000\045\000\045\000\075\000\255\255\255\255\255\255\
    \073\000\255\255\045\000\045\000\045\000\045\000\045\000\045\000\
    \045\000\045\000\045\000\045\000\045\000\045\000\045\000\045\000\
    \045\000\045\000\045\000\045\000\045\000\045\000\045\000\045\000\
    \045\000\045\000\045\000\045\000\060\000\062\000\064\000\255\255\
    \255\255\072\000\255\255\255\255\255\255\255\255\255\255\074\000\
    \255\255\255\255\065\000\066\000\255\255\255\255\255\255\255\255\
    \255\255\075\000\255\255\060\000\062\000\064\000\255\255\255\255\
    \255\255\068\000\067\000\069\000\070\000\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\065\000\066\000\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \060\000\062\000\064\000\068\000\067\000\069\000\070\000\071\000\
    \000\000\003\000\255\255\072\000\074\000\255\255\039\000\255\255\
    \255\255\255\255\255\255\255\255\255\255\008\000\255\255\255\255\
    \255\255\255\255\029\000\069\000\255\255\031\000\255\255\255\255\
    \255\255\071\000\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\030\000\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\065\000\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\041\000\046\000\
    \255\255\068\000\255\255\044\000\067\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\255\255\
    \255\255\255\255\255\255\255\255\255\255\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\046\000\
    \046\000\046\000\046\000\046\000\046\000\046\000\046\000\047\000\
    \255\255\255\255\255\255\255\255\255\255\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\072\000\
    \074\000\255\255\255\255\255\255\255\255\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\047\000\
    \047\000\047\000\047\000\047\000\047\000\047\000\047\000\048\000\
    \065\000\066\000\048\000\048\000\048\000\048\000\048\000\048\000\
    \048\000\048\000\048\000\048\000\048\000\255\255\255\255\068\000\
    \067\000\069\000\070\000\048\000\048\000\048\000\048\000\048\000\
    \048\000\048\000\048\000\048\000\048\000\048\000\048\000\048\000\
    \048\000\048\000\048\000\048\000\048\000\048\000\048\000\048\000\
    \048\000\048\000\048\000\048\000\048\000\071\000\255\255\255\255\
    \255\255\048\000\255\255\048\000\048\000\048\000\048\000\048\000\
    \048\000\048\000\048\000\048\000\048\000\048\000\048\000\048\000\
    \048\000\048\000\048\000\048\000\048\000\048\000\048\000\048\000\
    \048\000\048\000\048\000\048\000\048\000\049\000\255\255\255\255\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\255\255\255\255\255\255\255\255\255\255\
    \255\255\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\255\255\255\255\255\255\255\255\049\000\
    \255\255\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\049\000\049\000\049\000\049\000\049\000\
    \049\000\049\000\049\000\053\000\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\053\000\255\255\255\255\053\000\
    \053\000\053\000\053\000\053\000\053\000\053\000\053\000\053\000\
    \053\000\053\000\255\255\255\255\255\255\255\255\255\255\255\255\
    \053\000\053\000\053\000\053\000\053\000\053\000\053\000\053\000\
    \053\000\053\000\053\000\053\000\053\000\053\000\053\000\053\000\
    \053\000\053\000\053\000\053\000\053\000\053\000\053\000\053\000\
    \053\000\053\000\255\255\255\255\255\255\255\255\053\000\255\255\
    \053\000\053\000\053\000\053\000\053\000\053\000\053\000\053\000\
    \053\000\053\000\053\000\053\000\053\000\053\000\053\000\053\000\
    \053\000\053\000\053\000\053\000\053\000\053\000\053\000\053\000\
    \053\000\053\000\055\000\255\255\255\255\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \255\255\255\255\255\255\255\255\255\255\255\255\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \255\255\255\255\255\255\255\255\055\000\255\255\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \055\000\055\000\055\000\055\000\055\000\055\000\055\000\055\000\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
    \255\255\255\255\255\255\255\255\255\255\255\255";
  Lexing.lex_base_code = 
   "";
  Lexing.lex_backtrk_code = 
   "";
  Lexing.lex_default_code = 
   "";
  Lexing.lex_trans_code = 
   "";
  Lexing.lex_check_code = 
   "";
  Lexing.lex_code = 
   "";
}

let rec token c lexbuf =
    __ocaml_lex_token_rec c lexbuf 0
and __ocaml_lex_token_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 194 "xmllexer.mll"
                  ( update_loc c 1 false 0; Whitespace (lexeme c) )
# 441 "xmllexer.ml"

  | 1 ->
# 195 "xmllexer.mll"
                          (Whitespace (lexeme c) )
# 446 "xmllexer.ml"

  | 2 ->
# 201 "xmllexer.mll"
                 ( Comment(comment c lexbuf))
# 451 "xmllexer.ml"

  | 3 ->
# 202 "xmllexer.mll"
               ( header c lexbuf;  token c lexbuf )
# 456 "xmllexer.ml"

  | 4 ->
# 203 "xmllexer.mll"
                                (
                let tag = ident_name c lexbuf in
                ignore_spaces c lexbuf;
                close_tag c lexbuf;
                Endtag tag
        )
# 466 "xmllexer.ml"

  | 5 ->
# 209 "xmllexer.mll"
                     (
                let tag = ident_name c lexbuf in
                ignore_spaces c lexbuf;
                let attribs, closed = attributes c lexbuf in
                Tag(tag, attribs, closed)                   
        )
# 476 "xmllexer.ml"

  | 6 ->
# 215 "xmllexer.mll"
               (
                ignore(buff_contents c);
                store c ;
                PCData (pcdata c lexbuf)
        )
# 485 "xmllexer.ml"

  | 7 ->
# 220 "xmllexer.mll"
              (
                ignore (buff_contents c);
                store_string c (entity c lexbuf);
                PCData (pcdata c lexbuf)
        )
# 494 "xmllexer.ml"

  | 8 ->
# 225 "xmllexer.mll"
               (
                ignore (buff_contents c); 
                store_string c "$" ; 
                PCData (pcdata c lexbuf) 
        )
# 503 "xmllexer.ml"

  | 9 ->
# 230 "xmllexer.mll"
                         (
                ignore (buff_contents c);
                store c ;
                PCData (pcdata c lexbuf)
        )
# 512 "xmllexer.ml"

  | 10 ->
# 235 "xmllexer.mll"
              ( Eof )
# 517 "xmllexer.ml"

  | 11 ->
# 236 "xmllexer.mll"
                 (
                ignore (buff_contents c) ;
                store c ;
                CamlString (extract_caml (camlident c lexbuf) true)
        )
# 526 "xmllexer.ml"

  | 12 ->
# 241 "xmllexer.mll"
                   (
                ignore (buff_contents c) ;
                store c ;
                CamlList (extract_caml (camlident c lexbuf) true)
        )
# 535 "xmllexer.ml"

  | 13 ->
# 246 "xmllexer.mll"
              ( 
                ignore (buff_contents c) ;
                store c ;
                CamlExpr (extract_caml (camlident c lexbuf) false)
        )
# 544 "xmllexer.ml"

  | 14 ->
# 251 "xmllexer.mll"
            ( err ENodeExpected (Loc.of_lexbuf lexbuf) )
# 549 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_token_rec c lexbuf __ocaml_lex_state

and ignore_spaces c lexbuf =
    __ocaml_lex_ignore_spaces_rec c lexbuf 27
and __ocaml_lex_ignore_spaces_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 254 "xmllexer.mll"
                  (
                update_loc c 1 false 0;
                ignore_spaces c lexbuf
        )
# 563 "xmllexer.ml"

  | 1 ->
# 258 "xmllexer.mll"
                            ( ignore_spaces c lexbuf )
# 568 "xmllexer.ml"

  | 2 ->
# 259 "xmllexer.mll"
             ( () )
# 573 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_ignore_spaces_rec c lexbuf __ocaml_lex_state

and camlident c lexbuf =
    __ocaml_lex_camlident_rec c lexbuf 29
and __ocaml_lex_camlident_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 262 "xmllexer.mll"
                 ( update_loc c 1 false 0 ; store c ; camlident c lexbuf)
# 584 "xmllexer.ml"

  | 1 ->
# 263 "xmllexer.mll"
                        ( store c ; camlident c lexbuf)
# 589 "xmllexer.ml"

  | 2 ->
# 264 "xmllexer.mll"
             ( store c ; buff_contents c )
# 594 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_camlident_rec c lexbuf __ocaml_lex_state

and comment c lexbuf =
    __ocaml_lex_comment_rec c lexbuf 31
and __ocaml_lex_comment_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 271 "xmllexer.mll"
                  (
                update_loc c 1 false 0;
                comment c lexbuf
        )
# 608 "xmllexer.ml"

  | 1 ->
# 275 "xmllexer.mll"
                 (
(*              warn WIntricatedComments (Loc.of_lexbuf lexbuf) ; *)

                let buff = buff_contents c in 
                let in_comment = comment c lexbuf in
                store_string c buff ; 
                store_string c "<!--" ;
                store_string c in_comment ;
                store_string c "-->" ;
                comment c lexbuf
        )
# 623 "xmllexer.ml"

  | 2 ->
# 286 "xmllexer.mll"
                ( buff_contents c )
# 628 "xmllexer.ml"

  | 3 ->
# 287 "xmllexer.mll"
              ( err EUnterminatedComment (Loc.of_lexbuf lexbuf) )
# 633 "xmllexer.ml"

  | 4 ->
# 288 "xmllexer.mll"
             ( store c ; comment c lexbuf )
# 638 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_comment_rec c lexbuf __ocaml_lex_state

and header c lexbuf =
    __ocaml_lex_header_rec c lexbuf 39
and __ocaml_lex_header_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 292 "xmllexer.mll"
                  (
                update_loc c 1 false 0;
                header c lexbuf
        )
# 652 "xmllexer.ml"

  | 1 ->
# 296 "xmllexer.mll"
               ( () )
# 657 "xmllexer.ml"

  | 2 ->
# 297 "xmllexer.mll"
              ( err ECloseExpected (loc c) )
# 662 "xmllexer.ml"

  | 3 ->
# 298 "xmllexer.mll"
            ( header c lexbuf )
# 667 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_header_rec c lexbuf __ocaml_lex_state

and pcdata c lexbuf =
    __ocaml_lex_pcdata_rec c lexbuf 41
and __ocaml_lex_pcdata_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 301 "xmllexer.mll"
                  (
                store c ;
                pcdata c lexbuf
        )
# 681 "xmllexer.ml"

  | 1 ->
# 305 "xmllexer.mll"
               (
                store c ;
                pcdata c lexbuf;
        )
# 689 "xmllexer.ml"

  | 2 ->
# 309 "xmllexer.mll"
              (
                store_string c (entity c lexbuf);
                pcdata c lexbuf
        )
# 697 "xmllexer.ml"

  | 3 ->
# 313 "xmllexer.mll"
               ( store_string c "$" ; pcdata c lexbuf )
# 702 "xmllexer.ml"

  | 4 ->
# 314 "xmllexer.mll"
             ( buff_contents c )
# 707 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_pcdata_rec c lexbuf __ocaml_lex_state

and entity c lexbuf =
    __ocaml_lex_entity_rec c lexbuf 45
and __ocaml_lex_entity_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 317 "xmllexer.mll"
                          (
                let ident = lexeme c in
                if not c.entity then "&" ^ ident else
                try Hashtbl.find idents (String.lowercase ident)
                with Not_found -> "&" ^ ident
        )
# 723 "xmllexer.ml"

  | 1 ->
# 323 "xmllexer.mll"
                  ( err EUnterminatedEntity (Loc.of_lexbuf lexbuf) )
# 728 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_entity_rec c lexbuf __ocaml_lex_state

and ident_name c lexbuf =
    __ocaml_lex_ident_name_rec c lexbuf 48
and __ocaml_lex_ident_name_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 326 "xmllexer.mll"
                     ( lexeme c )
# 739 "xmllexer.ml"

  | 1 ->
# 327 "xmllexer.mll"
                  ( err EIdentExpected (loc c))
# 744 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_ident_name_rec c lexbuf __ocaml_lex_state

and close_tag c lexbuf =
    __ocaml_lex_close_tag_rec c lexbuf 50
and __ocaml_lex_close_tag_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 330 "xmllexer.mll"
              ( () )
# 755 "xmllexer.ml"

  | 1 ->
# 331 "xmllexer.mll"
                  ( err ECloseExpected (loc c))
# 760 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_close_tag_rec c lexbuf __ocaml_lex_state

and attributes c lexbuf =
    __ocaml_lex_attributes_rec c lexbuf 51
and __ocaml_lex_attributes_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 334 "xmllexer.mll"
               ( [], false )
# 771 "xmllexer.ml"

  | 1 ->
# 335 "xmllexer.mll"
               ( [], true )
# 776 "xmllexer.ml"

  | 2 ->
# 336 "xmllexer.mll"
                                        (
                let (attribute:attribute) = 
                        (match attribute c lexbuf with
                        | `Attr s as a  -> 
                                let (data:valeur) = attribute_data c lexbuf in
                                (`Attribute (a, data))
                        |`CamlAttr s as a ->
                                let (data:valeur) = attribute_data c lexbuf in
                                (`Attribute (a, data))			  
                        | (`CamlList s) as a -> a
                        ) in
                ignore_spaces c lexbuf;
                let others, closed = attributes c lexbuf in
                attribute :: others, closed
        )
# 795 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_attributes_rec c lexbuf __ocaml_lex_state

and attribute c lexbuf =
    __ocaml_lex_attribute_rec c lexbuf 53
and __ocaml_lex_attribute_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 353 "xmllexer.mll"
                     (`Attr (lexeme c) )
# 806 "xmllexer.ml"

  | 1 ->
# 354 "xmllexer.mll"
                    (
                ignore (buff_contents c) ;
                store c ;
                `CamlList (extract_caml(camlident c lexbuf) true)
        )
# 815 "xmllexer.ml"

  | 2 ->
# 359 "xmllexer.mll"
               (
                ignore (buff_contents c) ;
                store c ;                
                `CamlAttr (extract_caml(camlident c lexbuf) false)
        )
# 824 "xmllexer.ml"

  | 3 ->
# 364 "xmllexer.mll"
                  ( err EAttributeNameExpected (loc c))
# 829 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_attribute_rec c lexbuf __ocaml_lex_state

and attribute_data c lexbuf =
    __ocaml_lex_attribute_data_rec c lexbuf 60
and __ocaml_lex_attribute_data_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 370 "xmllexer.mll"
                (`CamlVal (extract_caml(lexeme c) true))
# 840 "xmllexer.ml"

  | 1 ->
# 372 "xmllexer.mll"
                (`CamlVal (extract_caml(lexeme c) false))
# 845 "xmllexer.ml"

  | 2 ->
# 373 "xmllexer.mll"
                                (
                ignore(buff_contents c) ;
                `Val(dq_string c lexbuf)
        )
# 853 "xmllexer.ml"

  | 3 ->
# 377 "xmllexer.mll"
                                 (
                ignore(buff_contents c) ;
                `Val(q_string c lexbuf)
        )
# 861 "xmllexer.ml"

  | 4 ->
# 381 "xmllexer.mll"
                  ( err EAttributeValueExpected (loc c))
# 866 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_attribute_data_rec c lexbuf __ocaml_lex_state

and dq_string c lexbuf =
    __ocaml_lex_dq_string_rec c lexbuf 72
and __ocaml_lex_dq_string_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 384 "xmllexer.mll"
              ( buff_contents c )
# 877 "xmllexer.ml"

  | 1 ->
# 385 "xmllexer.mll"
                            (
                istore_char c 1;
                dq_string c lexbuf
        )
# 885 "xmllexer.ml"

  | 2 ->
# 389 "xmllexer.mll"
              ( err EUnterminatedString (Loc.of_lexbuf lexbuf) )
# 890 "xmllexer.ml"

  | 3 ->
# 390 "xmllexer.mll"
            ( 
                istore_char c 0;
                dq_string c lexbuf
        )
# 898 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_dq_string_rec c lexbuf __ocaml_lex_state

and q_string c lexbuf =
    __ocaml_lex_q_string_rec c lexbuf 74
and __ocaml_lex_q_string_rec c lexbuf __ocaml_lex_state =
  match Lexing.engine __ocaml_lex_tables __ocaml_lex_state lexbuf with
      | 0 ->
# 396 "xmllexer.mll"
               ( buff_contents c )
# 909 "xmllexer.ml"

  | 1 ->
# 397 "xmllexer.mll"
                             (
                istore_char c 1;
                q_string c lexbuf
        )
# 917 "xmllexer.ml"

  | 2 ->
# 401 "xmllexer.mll"
               ( err EUnterminatedString (Loc.of_lexbuf lexbuf) )
# 922 "xmllexer.ml"

  | 3 ->
# 402 "xmllexer.mll"
            ( 
                istore_char c 0;
                q_string c lexbuf
        )
# 930 "xmllexer.ml"

  | __ocaml_lex_state -> lexbuf.Lexing.refill_buff lexbuf; __ocaml_lex_q_string_rec c lexbuf __ocaml_lex_state

;;

# 409 "xmllexer.mll"
 
let lexing_store s buff max =
        let rec self n s =
                if n >= max then n
                else
                        match Stream.peek s with
                        | Some x ->
                                        Stream.junk s;
                                        buff.[n] <- x;
                                        succ n
                        | _ -> n
                in
                self 0 s

let from_context c  =
        let next _ =
                let tok = with_curr_loc token c in
                let loc = Loc.of_lexbuf c.lexbuf in
                Some ((tok, loc))
                in Stream.from next

let from_lexbuf lb e =
        let c = { (default_context lb) with
        loc        = Loc.of_lexbuf lb; 
		entity = e }
        in from_context c

let setup_loc lb loc =
        let start_pos = Loc.start_pos loc in
        lb.lex_abs_pos <- start_pos.pos_cnum;
        lb.lex_curr_p  <- start_pos

let from_string loc entity str =
        let lb = Lexing.from_string str in
        setup_loc lb loc;
        from_lexbuf lb entity

let from_stream loc entity strm =
        let lb = Lexing.from_function (lexing_store strm) in
        setup_loc lb loc;
        from_lexbuf lb entity


# 980 "xmllexer.ml"
