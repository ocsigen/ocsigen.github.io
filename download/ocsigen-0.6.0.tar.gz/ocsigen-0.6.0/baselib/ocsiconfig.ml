(* Warning! ocsiconfig.ml is generated automatically from ocsiconfig.ml.IN!
   Do not modify it manually *)
(* Ocsigen
 * Copyright (C) 2005 Vincent Balat
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, with linking exception; 
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *)

open Ocsimisc

exception Config_file_error of string

(* General config *)
let config_file = ref "/etc/ocsigen/ocsigen.conf"
let verbose = ref false
let silent = ref false
let daemon = ref false
let veryverbose = ref false
let version_number = (**)"0.6.0"(**)
let mimefile = ref "/etc/ocsigen/mime.types"
let pidfile = ref None

(* Server config: *)
let (uploaddir : string option ref) = ref None
let logdir = ref "/var/log/ocsigen" 
let (default_static_dir : string option ref) = ref None
let default_user = ref "www-data" 
let default_group = ref "www-data"
let minthreads = ref 10 
let maxthreads = ref 1500 
let max_number_of_threads_queued = ref 100
let max_number_of_connections = ref 500
let mimefile = ref "/etc/ocsigen/mime.types" 
let connect_time_max = ref 60.
let keepalive_timeout = ref 15.
let netbuffersize = ref 8000
let filebuffersize = ref 500
let maxrequestbodysize = ref (Some (Int64.of_int 8000000))
let maxuploadfilesize = ref (Some (Int64.of_int 2000000))
let defaultcharset = ref (None : string option)


let set_uploaddir u = uploaddir := u
let set_logdir s = logdir := s
let set_configfile s = config_file := s
let set_pidfile s = pidfile := Some s
let set_default_static_dir s = 
   default_static_dir := Some s
let set_mimefile s = mimefile := s
let set_verbose () = verbose := true
let set_silent () = silent := true
let set_daemon () = set_silent (); daemon := true
let set_veryverbose () = verbose := true; veryverbose := true
let set_minthreads i = minthreads := i
let set_maxthreads i = maxthreads := i
let set_max_number_of_threads_queued i = 
  max_number_of_threads_queued := i
let set_max_number_of_connections i = max_number_of_connections := i
let set_connect_time_max i = connect_time_max := i
let set_keepalive_timeout i = keepalive_timeout := i
let set_netbuffersize i = netbuffersize := i
let set_filebuffersize i = filebuffersize := i
let set_maxuploadfilesize i = maxuploadfilesize := i
let set_maxrequestbodysize i = maxrequestbodysize := i
let set_default_charset o = defaultcharset := o

let get_uploaddir () = !uploaddir
let get_logdir () = !logdir
let get_config_file () = !config_file
let get_pidfile () = !pidfile
let get_mimefile () = !mimefile
let get_verbose () = !verbose
let get_silent () = !silent
let get_daemon () = !daemon
let get_veryverbose () = !veryverbose
let get_default_static_dir () = !default_static_dir
let get_default_user () = !default_user
let get_default_group () = !default_group
let get_minthreads () = !minthreads
let get_maxthreads () = !maxthreads
let get_max_number_of_threads_queued () = !max_number_of_threads_queued
let get_max_number_of_connections () = !max_number_of_connections
let get_connect_time_max () = !connect_time_max
let get_keepalive_timeout () = !keepalive_timeout
let get_netbuffersize () = !netbuffersize
let get_filebuffersize () = !filebuffersize
let get_maxuploadfilesize () = !maxuploadfilesize
let get_maxrequestbodysize () = !maxrequestbodysize
let get_default_charset () = !defaultcharset


let display_version () =
  print_string version_number;
  print_newline ();
  exit 0

let print_location loc =
  Printf.sprintf "%d-%d" (fst loc).Lexing.pos_cnum (snd loc).Lexing.pos_cnum


let _ = Arg.parse
    [("-c", Arg.String set_configfile, 
      "Alternate config file (default /etc/ocsigen/ocsigen.conf)");
     ("--config", Arg.String set_configfile, 
      "Alternate config file (default /etc/ocsigen/ocsigen.conf)");
     ("-s", Arg.Unit set_silent, "Silent mode (error messages in errors.log only)");
     ("--silent", Arg.Unit set_silent, "Silent mode (error messages in errors.log only)");
     ("-p", Arg.String set_pidfile, "Specify a file where to write the PIDs of servers");
     ("--pidfile", Arg.String set_pidfile, "Specify a file where to write the PIDs of servers");
     ("-v", Arg.Unit set_verbose, "Verbose mode");
     ("--verbose", Arg.Unit set_verbose, "Verbose mode");
     ("-V", Arg.Unit set_veryverbose, "Very verbose mode (debug)");
     ("--veryverbose", Arg.Unit set_veryverbose, "Very verbose mode (debug)");
     ("-d", Arg.Unit set_daemon, "Daemon mode (detach the process)");
     ("--daemon", Arg.Unit set_daemon, "Daemon mode (detach the process) (This is the default when there are more than 1 process)");
     ("--version", Arg.Unit display_version, "Display version number and exit")
   ]
    (fun _ -> ())
    "usage: ocsigen [-c configfile]"

let config = 
  try
    Simplexmlparser.xmlparser (get_config_file ())
  with
    Stdpp.Exc_located (fl,exn) -> 
      Printf.eprintf "%s" 
	("Syntax error in config file at location : "^(print_location fl));
      raise exn





