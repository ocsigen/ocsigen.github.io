type uri = string
type uris = uri
let uri_of_string s = s
let string_of_uri s = s


