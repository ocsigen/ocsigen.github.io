(* Warning! ocsiconfig.ml is generated automatically from ocsiconfig.ml.IN!
   Do not modify it manually *)
(* Ocsigen
 * Copyright (C) 2005 Vincent Balat
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, with linking exception; 
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *)

open Ocsimisc

exception Config_file_error of string
let number_of_servers = ref 0

type modules = 
    Cmo of string 
  | Host of 
      virtual_hosts * 
        ((string list (* path *) *
         (string list (* cmo to be loaded *) *
                 string option (* static dir *))) list)

type config = { mutable ports: int list;
                mutable sslports: int list;
		mutable modu: modules list;
		mutable private_key: string option;
		mutable certificate: string option;
		mutable uploaddir: string option;
		mutable logdir: string;
		mutable default_static_dir: string option;
		mutable user: string;
		mutable group: string;
		mutable minthreads: int;
		mutable maxthreads: int;
		mutable max_number_of_threads_queued: int;
		mutable max_number_of_connections: int;
		mutable mimefile: string;
		mutable connect_time_max: float;
		mutable keepalive_timeout: float;
		mutable netbuffersize: int;
		mutable filebuffersize: int;
		mutable maxuploadfilesize: int64 option;
		mutable maxrequestbodysize: int64 option
	      }

let config_file = ref "/etc/ocsigen/ocsigen.conf"
let verbose = ref false
let silent = ref false
let daemon = ref false
let veryverbose = ref false
let version_number = (**)"0.5.1"(**)
let mimefile = ref "/etc/ocsigen/mime.types"
let pidfile = ref None

let init_config () = 
  {ports = [];
   sslports = [];
   modu = [];
   private_key = None; 
   certificate = None; 
   uploaddir = None; logdir = "/var/log/ocsigen"; 
   default_static_dir = None;
   user = "www-data"; group = "www-data";
   minthreads = 10; 
   maxthreads = 1500; 
   max_number_of_threads_queued = 100;
   max_number_of_connections = 500;
   mimefile = "/etc/ocsigen/mime.types"; 
   connect_time_max = 60.;
   keepalive_timeout = 15.;
   netbuffersize = 8000;
   filebuffersize = 500;
   maxrequestbodysize = Some (Int64.of_int 8000000);
   maxuploadfilesize = Some (Int64.of_int 2000000);
 }


let sconf  = ref (init_config ())
let cfgs : config list ref = ref [](*(Array.init max_servers (init_config))*) 
let add_port cf i = cf.ports <- cf.ports@[i] (* I reverse the list *)
let add_sslport cf i = cf.sslports <- cf.sslports@[i] (* I reverse the list *)
let get_ports_n cf = cf.ports
let get_sslports_n cf = cf.sslports
let set_modules cf m = cf.modu <- m
let set_key cf k = cf.private_key <- Some k
let set_certificate cf c = cf.certificate <- Some c
let set_uploaddir cf u = cf.uploaddir <- u
let set_logdir cf s = cf.logdir <- s
let set_configfile s = config_file := s
let set_pidfile s = pidfile := Some s
let set_default_static_dir cf s = 
  (cf).default_static_dir <- Some s
let set_mimefile cf s = cf.mimefile <- s
let set_verbose () = verbose := true
let set_silent () = silent := true
let set_daemon () = set_silent (); daemon := true
let set_veryverbose () = verbose := true; veryverbose := true
let set_user cf s = cf.user <- s
let set_group cf s = cf.group <- s
let set_minthreads cf i = cf.minthreads <- i
let set_maxthreads cf i = cf.maxthreads <- i
let set_max_number_of_threads_queued cf i = 
  cf.max_number_of_threads_queued <- i
let set_max_number_of_connections cf i = cf.max_number_of_connections <- i
let set_connect_time_max cf i = cf.connect_time_max <- i
let set_keepalive_timeout cf i = cf.keepalive_timeout <- i
let set_netbuffersize cf i = cf.netbuffersize <- i
let set_filebuffersize cf i = cf.filebuffersize <- i
let set_maxuploadfilesize cf i = cf.maxuploadfilesize <- i
let set_maxrequestbodysize cf i = cf.maxrequestbodysize <- i
let set_number_of_servers x = number_of_servers := x
let get_ports () = !sconf.ports
let get_sslports () = !sconf.sslports
let get_modules cf = !sconf.modu
let get_key cf = cf.private_key
let get_certificate cf = cf.certificate
let get_uploaddir () = !sconf.uploaddir
let get_logdir () = !sconf.logdir
let get_config_file () = !config_file
let get_pidfile () = !pidfile
let get_mimefile () = !sconf.mimefile
let get_verbose () = !verbose
let get_silent () = !silent
let get_daemon () = !daemon
let get_veryverbose () = !veryverbose
let get_default_static_dir () = !sconf.default_static_dir
let get_user () = !sconf.user
let get_group () = !sconf.group
let get_minthreads () = !sconf.minthreads
let get_maxthreads () = !sconf.maxthreads
let get_max_number_of_threads_queued () = !sconf.max_number_of_threads_queued
let get_max_number_of_connections () = !sconf.max_number_of_connections
let get_connect_time_max () = !sconf.connect_time_max
let get_keepalive_timeout () = !sconf.keepalive_timeout
let get_netbuffersize () = !sconf.netbuffersize
let get_filebuffersize () = !sconf.filebuffersize
let get_maxuploadfilesize () = !sconf.maxuploadfilesize
let get_maxrequestbodysize () = !sconf.maxrequestbodysize


let display_version () =
  print_string version_number;
  print_newline ();
  exit 0

let print_location loc =
  Printf.sprintf "%d-%d" (fst loc).Lexing.pos_cnum (snd loc).Lexing.pos_cnum


let _ = Arg.parse
    [("-c", Arg.String set_configfile, 
      "Alternate config file (default /etc/ocsigen/ocsigen.conf)");
     ("--config", Arg.String set_configfile, 
      "Alternate config file (default /etc/ocsigen/ocsigen.conf)");
     ("-s", Arg.Unit set_silent, "Silent mode (error messages in errors.log only)");
     ("--silent", Arg.Unit set_silent, "Silent mode (error messages in errors.log only)");
     ("-p", Arg.String set_pidfile, "Specify a file where to write the PIDs of servers");
     ("--pidfile", Arg.String set_pidfile, "Specify a file where to write the PIDs of servers");
     ("-v", Arg.Unit set_verbose, "Verbose mode");
     ("--verbose", Arg.Unit set_verbose, "Verbose mode");
     ("-V", Arg.Unit set_veryverbose, "Very verbose mode (debug)");
     ("--veryverbose", Arg.Unit set_veryverbose, "Very verbose mode (debug)");
     ("-d", Arg.Unit set_daemon, "Daemon mode (detach the process)");
     ("--daemon", Arg.Unit set_daemon, "Daemon mode (detach the process) (This is the default when there are more than 1 process)");
     ("--version", Arg.Unit display_version, "Display version number and exit")
   ]
    (fun _ -> ())
    "usage: ocsigen [-c configfile]"

let config = 
  try
    Simplexmlparser.xmlparser (get_config_file ())
  with
    Stdpp.Exc_located (fl,exn) -> 
      Printf.eprintf "%s" 
	("Syntax error in config file at location : "^(print_location fl));
      raise exn





