print_string "toto";;
