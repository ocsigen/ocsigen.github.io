
open Utils
open Shared

module Conversation_map = Map.Make (Conversation)
module User_map = Map.Make (User)
module User_set_map = Map.Make (User_set)

(* Avoid global state ... seriously. *)
module State = struct
  type t = {
   conversation_to_div_map : Dom_html.divElement Js.t Conversation_map.t ref;
   conversations_for_users : Dom_html.inputElement Js.t User_set_map.t ref;
   user_elts : Dom_html.liElement Js.t User_map.t ref;
  }

  let init () = {
    conversation_to_div_map = ref Conversation_map.empty;
    conversations_for_users = ref User_set_map.empty;
    user_elts = ref User_map.empty;
  }

  let find_conversation_to_div_map conversation st =
    Conversation_map.find conversation !(st.conversation_to_div_map)
  let modify_conversation_to_div_map st f =
    modify st.conversation_to_div_map f

  let find_conversations_for_users users st =
    User_set_map.find users !(st.conversations_for_users)
  let modify_conversations_for_users st f =
    modify st.conversations_for_users f

  let find_user_elt st user =
    User_map.find user !(st.user_elts)
  let modify_user_elt st f =
    modify st.user_elts f
end

(** [add_conversation_message_callback] facilitates the possibility to add a callback function
    which is called whenever a new conversation is added.
  *)
let get_conversation_message_callbacks, add_conversation_message_callback =
  let message_callbacks : (State.t -> Conversation.message -> unit Lwt.t) list ref = ref [] in
  (fun () -> !message_callbacks),
  (fun callback -> push callback message_callbacks)

let handle_enter_pressed msg_author prompt_dom bus ev =
  if ev##keyCode = 13 then begin
    let msg_content = Js.to_string prompt_dom##value in
    prompt_dom##value <- Js.string "";
    Lwt.ignore_result **> Eliom_bus.write bus { Conversation.msg_author; msg_content };
    Js._false
  end else Js._true

let dispatch_message st user messages_dom ({ Conversation.msg_author; msg_content } as msg) =
  let message =
    let open HTML5.M in
    li [user_span ~self:user msg_author; span ~a:[a_class ["content"]] [pcdata msg_content]]
  in
  List.iter (fun f -> Lwt.ignore_result (f st msg)) (get_conversation_message_callbacks ());
  Dom.appendChild
    messages_dom
    (Eliom_client.Html5.of_element message);
  messages_dom##scrollTop <- messages_dom##scrollHeight

(* Create a new conversation in the UI *)
let append_conversation st user conversation conversations_elt =
  debug "append_conversation between %s" (User_set.to_string conversation.Conversation.users);
  let conversation_dom =
    let open HTML5 in
    let users_ul = ul ~a:[a_class ["participants"]] **>
      List.map (li -| singleton -| user_span ~self:user) **>
        User_set.elements **>
          User_set.filter (not -| User.equal user) **>
            conversation.Conversation.users
    in
    let messages = ul ~a:[a_class ["messages"]] [] in
    let prompt = input ~a:[a_class ["prompt"]] () in
    let prompt_dom = Eliom_client.Html5.of_input prompt in
    State.modify_conversations_for_users st **> User_set_map.add conversation.Conversation.users prompt_dom;

    (* Setup the event handlers *)
    ignore **> Lwt_stream.iter
      (dispatch_message st user (Eliom_client.Html5.of_element messages))
      (Eliom_bus.stream conversation.Conversation.bus);
    ignore **> Dom_html.addEventListener
      prompt_dom
      Dom_html.Event.keypress
      (Dom_html.handler (handle_enter_pressed user prompt_dom conversation.Conversation.bus))
      Js._true;

    Eliom_client.Html5.of_element **>
      div ~a:[a_class ["conversation"]]
        [div ~a:[a_class ["participants_complete"]]
           [span ~a:[a_class ["info_label"]]
              [pcdata "With: "];
            users_ul];
         messages; prompt]
  in
  State.modify_conversation_to_div_map st **> Conversation_map.add conversation conversation_dom;
  Dom.appendChild
    (Eliom_client.Html5.of_element conversations_elt)
    conversation_dom

(* Remvoe a conversation from the UI and stop close its bus. *)
let remove_conversation st conversation conversations_elt =
  debug "remove_conversation between %s" (User_set.to_string conversation.Conversation.users);
  Eliom_bus.close conversation.Conversation.bus;
  try
    let conversation_dom = State.find_conversation_to_div_map conversation st in
    State.modify_conversation_to_div_map st **> Conversation_map.remove conversation;
    State.modify_conversations_for_users st **> User_set_map.remove conversation.Conversation.users;
    Dom.removeChild
      (Eliom_client.Html5.of_div conversations_elt)
      conversation_dom
  with
    Not_found -> ()

(* Find the DOM element which resembles the prompt of the conversation between the given users *) 
let get_conversation_for_users st users =
  try Some (State.find_conversations_for_users users st) with Not_found -> None

(* The main dispatching function for events on the client's [channel]' *)
let dispatch_event st user conversations_elt = function
    Append_conversation conversation -> 
      debug "Received Append_conversation";
      append_conversation st user conversation conversations_elt 
  | Remove_conversation conversation -> 
      debug "Received Remove_conversation";
      remove_conversation st conversation conversations_elt

let on_focus_conversation_callbacks = ref []
let add_on_focus_conversation_callback f =
  on_focus_conversation_callbacks := f :: !on_focus_conversation_callbacks

let create_or_focus_conversation st create_dialog_service user other =
  fun _ ->
    let users = List.fold_right User_set.add [user;other] User_set.empty in
    try
      let conversation_dom = State.find_conversations_for_users users st in
      debug "Focus existing conversation between %s" (User_set.to_string users);
      conversation_dom##focus();
      List.iter (fun f -> f conversation_dom) !on_focus_conversation_callbacks
    with Not_found ->
      debug "No conversation_for_users found, create_dialog_service";
      Lwt.ignore_result **> Eliom_client.call_service create_dialog_service () other

(* Reflect changes of the [users] signal in the list of users in the UI *)
let change_users st user users_elt create_dialog_service users =
  let users_dom = Eliom_client.Html5.of_ul users_elt in
  (* First clear users list in UI. *)
  while Js.to_bool **> users_dom##hasChildNodes() do
    Js.Opt.iter (users_dom##firstChild) **> Dom.removeChild users_dom
  done;
  (* Then add all users to the list again. *)
  let create_user_li other =
    let user_span_elt = HTML5.M.li **> singleton **> user_span ~self:user other in
    let user_span_dom = Eliom_client.Html5.of_li user_span_elt in
    State.modify_user_elt st (User_map.add other user_span_dom);
    let open Event_arrows in begin
      ignore **> run (clicks user_span_dom **> arr **> create_or_focus_conversation st create_dialog_service user other) ()
    end;
    user_span_dom
  in
  User_set.iter (Dom.appendChild users_dom -| create_user_li) users

let onload_chat ~users_signal ~users_elt ~conversations_elt ~user ~channel ~conversations ~create_dialog_service =
  debug "onload chat";
  let st = State.init () in
  Eliom_comet.Configuration.(let c = new_configuration () in set_always_active c true);
  List.iter (append_conversation st user // conversations_elt) conversations;
  Lwt.ignore_result **> Lwt_stream.iter (dispatch_event st user conversations_elt) channel;
  let open Lwt_react in begin
    let other_users_signal = S.map (User_set.filter (not -| User.equal user)) users_signal in
    S.(keep **> map (change_users st user users_elt create_dialog_service) other_users_signal)
  end;
  ()
