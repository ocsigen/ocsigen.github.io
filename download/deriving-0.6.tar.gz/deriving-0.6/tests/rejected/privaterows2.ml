(* Private rows are currently not supported *)
type poly4 = private [> `A]
    deriving (Eq)
